const allMen = ["Plato", "Socrates", "Paul"];
let allMenAreMortal = true;

if(allMenAreMortal && allMen.includes("Socrates")) {
  console.log("Socrates is mortal.");
}

// extra