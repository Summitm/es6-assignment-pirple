<h1>For this task - breaking the problem to small chunks</h1>

1. Get a google api key to use on the map
2. First call the navigator.geolocation to allow access of users location
3. Call the getCurrentLocation method of the navigator to get the current location cords
4. Init google maps with the above cords
5. Show the pin
6. Call the wachLocation to watch changing loaction
7. Continue maping user location
8. sOptionally: try to show direction to the nearest library.