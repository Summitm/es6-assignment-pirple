/* MetaData of my favourite song. 
Put into different data types */

var songTitle = "Afterglow";
var artist = "Ed Sheeran";
var album = "Afterglow";

var dateReleased = "21-12-2020"; //date uploaded on youtube
var age = 5 //Age in months

var isOnYoutube = true;
function DirectorListing(name, role) {
    this.name = name;
    this.role = role;
    this.result = function(){ 
        console.log(this.role +" is "+ this.name);
    }; 
}

// licensed to youtube by
var licensedBy = ["WMG", "LatinAutor - UMPG", "BMI - Broadcast Music Inc.", "6 Music Rights Societies"]; 

console.log(songTitle);
console.log("Available on youtube: "+ isOnYoutube);
console.log(licensedBy[3]); //Licensor at index 3

var director1 = new DirectorListing("Nic Minns", "Main Director");
director1.result();

